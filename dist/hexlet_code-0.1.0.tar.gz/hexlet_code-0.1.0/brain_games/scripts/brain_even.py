#!usr/bin/env python3


from brain_games.play_brain_even import initialize_game, play_brain_even


def main():
    return play_brain_even()


if __name__ == '__main__':
    main()
