### Hexlet tests and linter status:
[![Actions Status](https://github.com/alllexxx1/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/alllexxx1/python-project-49/actions)
<a href="https://codeclimate.com/github/alllexxx1/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/fa33867e39452019b806/maintainability" /></a>
<a href="https://asciinema.org/a/wOLdMdBNilUmFj1zIsaGzMQzM" target="_blank"><img src="https://asciinema.org/a/wOLdMdBNilUmFj1zIsaGzMQzM.svg" /></a>
